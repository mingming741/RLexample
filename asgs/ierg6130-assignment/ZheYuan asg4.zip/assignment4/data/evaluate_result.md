winning rate matrix:

|          |   MY_AGENT |   RANDOM |   WEAK |   MEDIUM |   STRONG |   RULE_BASED |   ALPHA_PONG |
|:---------|-----------:|---------:|-------:|---------:|---------:|-------------:|-------------:|
| MY_AGENT |        0.5 |        1 |    0.5 |        0 |        0 |            0 |            0 |




reward matrix

|          |   MY_AGENT |   RANDOM |   WEAK |   MEDIUM |   STRONG |   RULE_BASED |   ALPHA_PONG |
|:---------|-----------:|---------:|-------:|---------:|---------:|-------------:|-------------:|
| MY_AGENT |          1 |       11 |     -1 |      -10 |       -7 |           -9 |          -13 |