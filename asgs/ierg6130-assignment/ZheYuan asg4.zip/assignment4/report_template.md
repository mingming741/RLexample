# IERG 6130 Assignment 4 Report

Student Name: YOUR-NAME

Studnet ID: YOUR-SID

[TODO] Rename this file to `report_YOUR-SID.md` and remove this line.



## Winning Rate Matrix

|          | MY_AGENT | RANDOM | WEAK | MEDIUM | STRONG | RULE_BASED | ALPHA_PONG |
| :------- | -------: | -----: | ---: | -----: | -----: | ---------: | ---------: |
| MY_AGENT |      0.5 |      1 |    0 |      0 |      0 |          0 |          0 |

## Reward Matrix

|          | MY_AGENT | RANDOM | WEAK | MEDIUM | STRONG | RULE_BASED | ALPHA_PONG |
| :------- | -------: | -----: | ---: | -----: | -----: | ---------: | ---------: |
| MY_AGENT |        1 |      2 |  -17 |    -18 |    -15 |        -14 |        -17 |

## Description (if applicable)

